import io
import os
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import Response
from PIL import Image, UnidentifiedImageError
import numpy as np
import torch
from basicsr.archs.rrdbnet_arch import RRDBNet
from realesrgan import RealESRGANer

app = FastAPI(title="4K AI Upscaler")
MAX_UPLOAD_BYTES = 12 * 1024 * 1024
MODEL_PATH = os.getenv("MODEL_PATH", "/models/RealESRGAN_x4plus.pth")
upsampler = None

@app.on_event("startup")
def load_model():
    global upsampler
    if not os.path.exists(MODEL_PATH):
        raise RuntimeError(f"Model file missing: {MODEL_PATH}")
    model = RRDBNet(
        num_in_ch=3, num_out_ch=3, num_feat=64,
        num_block=23, num_grow_ch=32, scale=4
    )
    use_cuda = torch.cuda.is_available()
    upsampler = RealESRGANer(
        scale=4,
        model_path=MODEL_PATH,
        model=model,
        tile=256 if use_cuda else 128,
        tile_pad=10,
        pre_pad=0,
        half=use_cuda,
        device=torch.device("cuda" if use_cuda else "cpu")
    )

@app.get("/health")
def health():
    return {"status": "ok", "engine": "Real-ESRGAN x4"}

@app.post("/upscale")
async def upscale(image: UploadFile = File(...), scale: int = Form(4)):
    if scale != 4:
        raise HTTPException(400, "Only scale=4 is supported")
    raw = await image.read(MAX_UPLOAD_BYTES + 1)
    if len(raw) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "Image is too large; maximum is 12 MB")
    try:
        pil = Image.open(io.BytesIO(raw)).convert("RGB")
        if pil.width * pil.height > 16_000_000:
            raise HTTPException(413, "Image dimensions are too large")
        source = np.array(pil)[:, :, ::-1]
    except (UnidentifiedImageError, OSError):
        raise HTTPException(400, "Invalid image")
    try:
        output, _ = upsampler.enhance(source, outscale=4)
        output_rgb = output[:, :, ::-1]
        out = io.BytesIO()
        Image.fromarray(output_rgb).save(out, format="PNG", optimize=True)
        return Response(content=out.getvalue(), media_type="image/png")
    except Exception as exc:
        raise HTTPException(500, "Image processing failed") from exc
