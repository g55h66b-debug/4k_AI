# مشروع 4K AI — نسخة تطوير كاملة

المشروع يحتوي على:
1. تطبيق Android أصلي بلغة Kotlin.
2. خادم Python مبني على FastAPI.
3. محرك Real-ESRGAN x4 لمعالجة الصور.
4. نقطة API متوافقة مع التطبيق: `POST /upscale`.

## ما الذي يعمل الآن؟
الكود والربط جاهزان من ناحية المصدر. لكن التطبيق لا يستطيع تنفيذ AI فعلياً حتى يتم نشر الخادم على استضافة تدعم Python ويفضل GPU، ثم وضع رابط HTTPS في `MainActivity.kt`.

## نشر الخادم
- انشر مجلد `backend` على خادم Linux يدعم Docker.
- يفضّل GPU من NVIDIA مع CUDA لتسريع المعالجة. التشغيل على CPU ممكن لكنه قد يكون بطيئاً جداً.
- افتح HTTPS عبر منصة الاستضافة أو reverse proxy.
- اختبر `https://YOUR-HOST/health` ويجب أن يرجع status=ok.
- ضع الرابط الكامل `https://YOUR-HOST/upscale` في متغير `apiUrl` داخل MainActivity.kt.
- أعد بناء تطبيق Android.

## بناء APK
افتح المجلد في Android Studio، انتظر Gradle Sync، ثم اختر:
Build > Build Bundle(s) / APK(s) > Build APK(s)

الناتج عادة يكون في:
`app/build/outputs/apk/debug/app-debug.apk`

## تنبيه مهم
هذا المشروع ليس تطبيقاً منشوراً ولا APK جاهزاً بعد. لا أستطيع إنشاء حساب استضافة أو قبول شروطها أو تشغيل خدمة مدفوعة نيابةً عنك. لا تشارك كلمات مرورك أو بيانات الدفع. Real-ESRGAN يقدّر تفاصيل جديدة وقد لا يعيد التفاصيل الأصلية بدقة تامة.
