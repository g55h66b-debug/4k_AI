package com.example.fkai

import android.content.ContentValues
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class MainActivity : ComponentActivity() {
    // Set this to the HTTPS address of your deployed backend.
    private val apiUrl = "https://YOUR-SERVER-DOMAIN.com/upscale"
    private val client = OkHttpClient()
    private var selectedUri: Uri? = null
    private var resultBytes: ByteArray? = null
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var enhanceButton: Button
    private lateinit var saveButton: Button

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            resultBytes = null
            contentResolver.openInputStream(uri)?.use {
                preview.setImageBitmap(BitmapFactory.decodeStream(it))
            }
            status.text = "تم اختيار الصورة. اضغط تحسين بالذكاء الاصطناعي."
            saveButton.isEnabled = false
            enhanceButton.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF0A0F1E.toInt()
        window.navigationBarColor = 0xFF0A0F1E.toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(0xFF0A0F1E.toInt())
        }
        layout.addView(TextView(this).apply {
            text = "4K AI"
            textSize = 32f
            setTextColor(0xFF36D7FF.toInt())
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        layout.addView(TextView(this).apply {
            text = "AI Photo Enhancer"
            textSize = 14f
            setTextColor(-1)
            gravity = Gravity.CENTER
        })
        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF182238.toInt())
            contentDescription = "معاينة الصورة"
        }
        layout.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            setMargins(0, 24, 0, 18)
        })
        status = TextView(this).apply {
            text = "اختار صورة حتى تبدأ"
            textSize = 14f
            setTextColor(-1)
            gravity = Gravity.CENTER
        }
        layout.addView(status)
        fun addButton(label: String, action: () -> Unit): Button {
            val b = Button(this).apply { text = label; setOnClickListener { action() } }
            layout.addView(b, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, 7, 0, 7)
            })
            return b
        }
        addButton("اختيار صورة") { picker.launch("image/*") }
        enhanceButton = addButton("تحسين بالذكاء الاصطناعي") { uploadForEnhancement() }
        enhanceButton.isEnabled = false
        saveButton = addButton("حفظ الصورة المحسّنة") { saveResult() }
        saveButton.isEnabled = false
        setContentView(layout)
    }

    private fun uploadForEnhancement() {
        val uri = selectedUri ?: return
        if (apiUrl.contains("YOUR-SERVER-DOMAIN")) {
            status.text = "خادم الذكاء الاصطناعي لم يتم نشره وربطه بعد."
            return
        }
        enhanceButton.isEnabled = false
        status.text = "جاري تحسين الصورة بالذكاء الاصطناعي..."
        Thread {
            try {
                val temp = File(cacheDir, "upload_image")
                contentResolver.openInputStream(uri)?.use { source ->
                    FileOutputStream(temp).use { target -> source.copyTo(target) }
                } ?: throw IOException("تعذر قراءة الصورة")
                val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("scale", "4")
                    .addFormDataPart("image", "photo.jpg",
                        temp.asRequestBody("application/octet-stream".toMediaType()))
                    .build()
                val request = Request.Builder().url(apiUrl).post(body).build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw IOException("خطأ بالخادم: ${response.code}")
                    resultBytes = response.body?.bytes() ?: throw IOException("استجابة فارغة")
                }
                runOnUiThread {
                    val bytes = resultBytes!!
                    preview.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))
                    status.text = "اكتمل التحسين بالذكاء الاصطناعي."
                    saveButton.isEnabled = true
                    enhanceButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "تعذر التحسين: ${e.message}"
                    enhanceButton.isEnabled = true
                }
            }
        }.start()
    }

    private fun saveResult() {
        val bytes = resultBytes ?: return
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "4K_AI_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/4K AI")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("تعذر إنشاء الملف")
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            Toast.makeText(this, "تم حفظ الصورة في Pictures/4K AI", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "فشل الحفظ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
